README.txt

Algorithmic Murmuration

Exam No: Y3926325
===========================

This project is a flocking simulation program written in Java, version 11. The simulation demonstrates the behaviours of agents (boids) that exhibit flocking patterns, while avoiding obstacles and predators. The system is controlled via a graphical user interface (GUI).

Source Files
============

The following Java source files are included in this project:

1. MySimulationEngine.java
2. MySimulationGUI.java
3. MyHawk.java
4. Boid.java
5. Predator.java
6. Prey.java
7. SimEntity.java
8. DynamicMouse.java
9. Obstacle.java
10. Canvas.java
11. CartesianCoordinate.java
12. LineSegment.java
13. Utils.java

Entry Point
===========

The main method resides within the **MurmurationAppLauncher** class. To run the program, execute the **MurmurationAppLauncher** class.

Description of Source Files
===========================

1. **MySimulationEngine.java**: The main class that executes the simulation. It initialises the agents, obstacles, predators, and the environment. The class controls the simulation loop and various agent behaviours.

2. **MySimulationGUI.java**: Responsible for constructing and managing the graphical user interface. It includes sliders for adjusting simulation parameters, buttons for controlling boid and predator populations, and a display area for the simulation.

3. **MyHawk.java**: Represents the predators in the simulation. Predators are agents that chase boids (prey) and interact with obstacles.

4. **Boid.java**: The agent representing a boid in the simulation. It exhibits flocking behaviour, including cohesion, alignment, and separation, and can avoid obstacles and predators.

5. **Predator.java**: The interface for predator entities in the simulation, outlining necessary behaviours such as hunting and avoiding obstacles.

6. **Prey.java**: The interface for prey entities (like boids) that need to flee from predators.

7. **SimEntity.java**: The common interface for all simulation entities, including boids, predators, and obstacles. It defines the basic methods for rendering, updating, and interacting with other entities.

8. **DynamicMouse.java**: An invisible obstacle that tracks the mouse position. Boids exhibit behaviour based on the proximity of this dynamic obstacle, such as fleeing or avoiding it.

9. **Obstacle.java**: This interface defines the general structure for obstacles in the simulation, providing methods for drawing, clearing, and collision detection.

10. **Canvas.java**: The class responsible for managing and rendering the graphical canvas for the simulation. It draws lines and shapes based on the entities in the simulation.

11. **CartesianCoordinate.java**: Represents a 2D point in the Cartesian coordinate system. It includes methods for distance and angle calculations.

12. **LineSegment.java**: Represents a line segment, with methods for calculating the length and angle of the line segment between two points.

13. **Utils.java**: A utility class providing methods used across the simulation, such as the `pause` method and random number generation.

---

